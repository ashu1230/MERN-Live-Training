// import logo from './logo.svg';
import './App.css';
import { NotePage } from './modules/notes/pages/NotePage';
 
function App() {
  return (
    <NotePage/>
 
  );
}
 
export default App;