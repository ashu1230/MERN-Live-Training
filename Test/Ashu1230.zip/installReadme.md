Steps to create a new single page react App below:

Step1: Install node js
Step2: VS Code
Step3: Create a new Folder -> ReactFolio
Step4: change directory to ReactFolio
Step5: npx create-react-app demoshopapp
Step6: change directory to demoshopapp
Step7: npm start